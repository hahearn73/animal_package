from setuptools import setup, find_packages

setup(
    name='hahearn73_animal_package',
    version='0.1',
    description='A package for working with animals',
    author='Harrison Ahearn',
    author_email='hahearn730@gmail.com',
    packages=find_packages(),
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.6',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: Implementation :: CPython',
        'Programming Language :: Python :: Implementation :: PyPy'
    ],
    python_requires='>=3.6',
    install_requires=[
        # add any dependencies required by your package here
    ],
)
